import React from 'react';
import Home from './Utilities/Home';
import Weather from './Utilities/Weather';
import Monitor from './Utilities/Monitor';
import Resources from './Utilities/Resources';
import Maps from './Utilities/Maps';
import Predictions from './Utilities/Predictions';

class Dashboard extends React.Component {

    utilityComponents = {

        dashboard: Home,
        weather: Weather,
        monitor: Monitor,
        resources: Resources,
        maps: Maps,
        predictions: Predictions,

    }

    constructor(props) {
        super(props);
        this.state = { currentDashboardScreen: "dashboard" };
        const CurrentUtility = this.utilityComponents[this.state.currentDashboardScreen];
      
    }

 
    render() {

        const CurrentUtility = this.utilityComponents[this.state.currentDashboardScreen];
          
        return(
            <div id='appContainer' className='screen'>

                <aside id='navContainer'>
                    <div id='navTop'>
                    <img src={require('../../resources/img/logo.png')} alt="agrosense logo"/>
                    </div>
                    <nav>
                        <ul>
                            <li onClick={() => this.setState({currentDashboardScreen: "dashboard"})} className='navActive'><p><i className="fa-solid fa-table-cells-large"></i>Dashboard</p></li>
                            <li onClick={() => this.setState({currentDashboardScreen: "weather"})}><p><i className="fa-solid fa-cloud-sun"></i>Weather</p></li>
                            <li onClick={() => this.setState({currentDashboardScreen: "monitor"})}><p><i className="fa-solid fa-desktop"></i>Monitor</p></li>
                            <li onClick={() => this.setState({currentDashboardScreen: "resources"})}><p><i className="fa-solid fa-boxes-stacked"></i>Resources</p></li>
                            <li onClick={() => this.setState({currentDashboardScreen: "maps"})}><p><i className="fa-regular fa-map"></i>Maps</p></li>
                            <li onClick={() => this.setState({currentDashboardScreen: "predictions"})}><p><i className="fa-solid fa-bullhorn"></i>Predictions</p></li>
                        </ul>
                    </nav>
                    <hr className='greenLine'/>
                </aside>

                <main id='utilityContainer'>

                <CurrentUtility/>

                </main>

            </div>
        )
    }

}

export default Dashboard;