import React from "react";

class Monitor extends React.Component {

    render() {
        return (
            <h1>Monitor</h1>
        )
    }
}

export default Monitor;