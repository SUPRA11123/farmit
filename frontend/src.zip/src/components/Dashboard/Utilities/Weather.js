import React from "react";

class Weather extends React.Component {

    render() {
        return (
            <h1>Weather</h1>
        )
    }
}

export default Weather;