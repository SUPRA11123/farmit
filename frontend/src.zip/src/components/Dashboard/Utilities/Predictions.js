import React from "react";

class Predictions extends React.Component {

    render() {
        return (
            <h1>Predictions</h1>
        )
    }
}

export default Predictions;