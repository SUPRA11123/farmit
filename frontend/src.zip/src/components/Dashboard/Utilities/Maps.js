import React from "react";

class Maps extends React.Component {

    render() {
        return (
            <h1>Maps</h1>
        )
    }
}

export default Maps;