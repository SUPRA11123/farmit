import React from "react";

class Resources extends React.Component {

    render() {
        return (
            <h1>Resources</h1>
        )
    }
}

export default Resources;